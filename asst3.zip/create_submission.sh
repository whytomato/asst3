cd saxpy/
make clean
cd ../scan/
make clean
cd ../render/
make clean
cd ../
tar -czvf asst3.tar.gz saxpy scan render
